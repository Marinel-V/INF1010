#pragma once
const int espace_nom = 20;
const int espace_horaires = 10;
const int espace_domaine = 20;
const int espace_niveau = 10;
const int espace_prenom = 18;
const int espace_chambre = 15;

const int espacement_medecin = espace_nom + 2*espace_horaires + espace_domaine + 2*espace_niveau;

const int espacement_infirmier = espace_nom + espace_prenom + 2*espace_chambre;
